'use strict'
const AWS = require('aws-sdk');

exports.handler = async (event) => {
    console.log(JSON.stringify(`Event: event`))
    // Lambda Code Here
    // context.succeed('Success!')
    // context.fail('Failed!')
}